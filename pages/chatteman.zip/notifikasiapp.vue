<template>
  <div class="max-w-xl w-full mx-auto">
    <div class="flex py-5 px-4 bg-white shadow-xl">
      <div class="flex">
        <a href="/homeapp">
          <svg width="11" height="19" viewBox="0 0 11 19" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 2L3 9.1875L9 17" stroke="#0075FF" stroke-width="4" stroke-linecap="round" />
          </svg>
        </a>
        <h1 class="font-medium text-base mx-auto pl-4" style="color:rgba(50, 11, 78, 1)">
          Notifikasi
        </h1>
      </div>
    </div>
    <div class="bg-white h-screen shadow-lg border-t-2">
      <div class="pt-4">
        <div class="px-4">
          <div class="w-full h-20 rounded-lg" style="background-color: rgba(251, 254, 255, 1); box-shadow: 0px 0px 4px 1px rgba(0, 0, 0, 0.25);">
            <h1 class="text-center text-base font-semibold pt-4" style="color: rgba(68, 68, 68, 1)">
              Konfigurasi
            </h1>
            <p class="text-sm font-medium text-center" style="color: rgba(68, 68, 68, 1)">
              Kamis,2 Maret 2023   Libur Hari Indah
            </p>
          </div>
        </div>
      </div>
      <div class="py-4 px-4">
        <div class="border-b" />
      </div>
      <div class="px-4">
        <div class="w-full h-28 rounded-lg" style="background-color: rgba(251, 254, 255, 1); box-shadow: 0px 0px 4px 1px rgba(0, 0, 0, 0.25);">
          <div class="px-4 py-4">
            <div class="flex">
              <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="24" cy="24" r="23" stroke="#0075FF" stroke-width="2" />
              </svg>
              <div class="flex flex-col pl-4">
                <h1 class="text-base font-semibold" style="color: rgba(68, 68, 68, 1);">
                  Alvinn
                </h1>
                <p class="text-sm font-medium text-center" style="color: rgba(140, 140, 140, 1)">
                  Mengundang anda kedalam meet
                </p>
              </div>
            </div>
            <div class="flex justify-between">
              <p class="items-center pt-4 text-xs font-medium text-gray-400">
                09.00
              </p>
              <button class="w-36 text-white font-medium text-sm px-2 py-2 rounded-lg bg-blue-600 hover:opacity-80 transition-all focus:ring-4 focus:ring-blue-800 focus:opacity-100">
                Masuk Sekarang
              </button>
            </div>
          </div>
        </div>
      </div>
      <div class="px-4 py-4">
        <div class="w-full h-28 rounded-lg" style="background-color: rgba(251, 254, 255, 1); box-shadow: 0px 0px 4px 1px rgba(0, 0, 0, 0.25);">
          <div class="px-4 py-4">
            <div class="flex">
              <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="24" cy="24" r="23" stroke="#0075FF" stroke-width="2" />
              </svg>
              <div class="flex flex-col pl-4">
                <div class="flex">
                  <h1 class="text-base font-semibold" style="color: rgba(68, 68, 68, 1);">
                    Ayu Permata
                  </h1>
                  <p class="translate-y-1 text-xs text-blue-600 font-normal pl-2">
                    Admin
                  </p>
                </div>
                <p class="text-sm font-medium text-center" style="color: rgba(140, 140, 140, 1)">
                  Selamat pagi,cek point pagi kita mulai jam 09.20.
                </p>
              </div>
            </div>
            <div class="flex justify-between">
              <p class="items-center pt-4 text-xs font-medium text-gray-400">
                09.00
              </p>
              <button class="w-36 text-white font-medium text-sm px-2 py-2 rounded-lg bg-blue-600 hover:opacity-80 transition-all focus:ring-4 focus:ring-blue-800 focus:opacity-100">
                Masuk Sekarang
              </button>
            </div>
          </div>
        </div>
      </div>
      <div class="px-4">
        <div class="w-full h-28 rounded-lg" style="background-color: rgba(251, 254, 255, 1); box-shadow: 0px 0px 4px 1px rgba(0, 0, 0, 0.25);">
          <div class="px-4 py-4">
            <div class="flex">
              <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="24" cy="24" r="23" stroke="#0075FF" stroke-width="2" />
              </svg>
              <div class="flex flex-col pl-4">
                <h1 class="text-base font-semibold" style="color: rgba(68, 68, 68, 1);">
                  Ayu Permata
                </h1>
                <p class="text-sm font-medium text-center" style="color: rgba(140, 140, 140, 1)">
                  Selamat pagi,cek point pagi kita mulai jam 09.20
                </p>
              </div>
            </div>
            <div class="flex justify-between">
              <p class="items-center pt-4 text-xs font-medium text-gray-400">
                09.00
              </p>
              <p class="font-medium text-lg text-slate-200 translate-y-1 pt-2">
                Sesi Telah Berakhir
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
