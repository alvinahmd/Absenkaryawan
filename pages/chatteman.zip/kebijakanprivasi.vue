<template>
  <div>
    <div class="my-0 mx-auto min-h-full max-w-screen-sm">
      <div class="relative flex flex-row py-5 px-4 bg-white shadow-lg">
        <router-link to="/proflogin">
          <img src="/back.svg">
        </router-link>
        <h1 class="font-bold mx-auto" style="color:rgba(68, 68, 68, 1)">
          Kebijakan Privasi
        </h1>
      </div>
      <div class=" container p-5 pb-60 bg-white shadow-md">
        <div class="pl-5 ">
          <p class="text-xl poppins" style="color:rgba(92, 92, 92, 1);">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
            consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
            cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
            proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Ut enim ad minim veniam,quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodoconsequat. Duis aute irure dolor in reprehenderit in voluptate velit essecillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
          </p>
        </div>
      </div>
    </div>
  </div>
</template>
