<template>
  <div class="max-w-xl w-full mx-auto">
    <div class="py-5 px-4 bg-white shadow-xl border-b-2">
      <div class="flex">
        <a href="/riwayatapp">
          <svg width="11" height="19" viewBox="0 0 11 19" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 2L3 9.1875L9 17" stroke="#0075FF" stroke-width="4" stroke-linecap="round" />
          </svg>
        </a>
        <h1 class="font-medium text-base mx-auto pl-4" style="color:rgba(50, 11, 78, 1)">
          Desember2022
        </h1>
        <div class="justify-end">
          <img src="download.svg" alt="">
        </div>
      </div>
    </div>
    <div class="w-full h-screen" style="background-color: rgba(242, 251, 255, 1)">
      <div class="pt-2">
        <table class="items-center w-full  bg-white border-none">
          <tr class="text-center rounded-t-xl" color="rgba(68, 68, 68, 1)">
            <td class="py-4 text-base font-medium">
              7.35 PM
            </td>
            <td class="text-base font-semibold">
              1 Des 2022
            </td>
            <td class="text-base font-medium">
              16.54 PM
            </td>
          </tr>
        </table>
        <div class="pt-2">
          <table class="items-center w-full  bg-white border-none">
            <tr class="text-center rounded-t-xl" color="rgba(68, 68, 68, 1)">
              <td class="py-4 text-base font-medium">
                7.35 PM
              </td>
              <td class="text-base font-semibold">
                1 Des 2022
              </td>
              <td class="text-base font-medium">
                16.54 PM
              </td>
            </tr>
          </table>
          <div class="pt-2">
            <table class="items-center w-full  bg-white border-none">
              <tr class="text-center rounded-t-xl" color="rgba(68, 68, 68, 1)">
                <td class="py-4 text-base font-medium">
                  7.35 PM
                </td>
                <td class="text-base font-semibold">
                  1 Des 2022
                </td>
                <td class="text-base font-medium">
                  16.54 PM
                </td>
              </tr>
            </table>
            <div class="pt-2">
              <table class="items-center w-full  bg-white border-none">
                <tr class="text-center rounded-t-xl" color="rgba(68, 68, 68, 1)">
                  <td class="py-4 text-base font-medium">
                    7.35 PM
                  </td>
                  <td class="text-base font-semibold">
                    1 Des 2022
                  </td>
                  <td class="text-base font-medium">
                    16.54 PM
                  </td>
                </tr>
              </table>
              <div class="pt-2">
                <table class="items-center w-full  bg-white border-none">
                  <tr class="text-center rounded-t-xl" color="rgba(68, 68, 68, 1)">
                    <td class="py-4 text-base font-medium">
                      7.35 PM
                    </td>
                    <td class="text-base font-semibold">
                      1 Des 2022
                    </td>
                    <td class="text-base font-medium">
                      16.54 PM
                    </td>
                  </tr>
                </table>
                <div class="pt-2">
                  <table class="items-center w-full  bg-white border-none">
                    <tr class="text-center rounded-t-xl" color="rgba(68, 68, 68, 1)">
                      <td class="py-4 text-base font-medium">
                        7.35 PM
                      </td>
                      <td class="text-base font-semibold">
                        1 Des 2022
                      </td>
                      <td class="text-base font-medium">
                        16.54 PM
                      </td>
                    </tr>
                  </table>
                  <div class="pt-2">
                    <table class="items-center w-full  bg-white border-none">
                      <tr class="text-center rounded-t-xl" color="rgba(68, 68, 68, 1)">
                        <td class="py-4 text-base font-medium">
                          7.35 PM
                        </td>
                        <td class="text-base font-semibold">
                          1 Des 2022
                        </td>
                        <td class="text-base font-medium">
                          16.54 PM
                        </td>
                      </tr>
                    </table>
                    <div class="pt-2">
                      <table class="items-center w-full  bg-white border-none">
                        <tr class="text-center rounded-t-xl" color="rgba(68, 68, 68, 1)">
                          <td class="py-4 text-base font-medium">
                            7.35 PM
                          </td>
                          <td class="text-base font-semibold">
                            1 Des 2022
                          </td>
                          <td class="text-base font-medium">
                            16.54 PM
                          </td>
                        </tr>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
