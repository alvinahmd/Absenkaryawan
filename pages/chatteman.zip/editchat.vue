<template>
  <div class="h-full">
    <div class="max-w-xl w-full mx-auto bg-white h-screen" style="box-shadow: 0px 1px 4px 0px rgba(0, 0, 0, 0.25);">
      <div class="flex py-2 px-4 items-center" style="box-shadow: 0px 1px 4px 0px rgba(0, 0, 0, 0.25);">
        <a href="/temankosong">
          <svg width="11" height="19" viewBox="0 0 11 19" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 2L3 9.1875L9 17" stroke="#0075FF" stroke-width="4" stroke-linecap="round" />
          </svg>
        </a>
        <h1 class="font-medium text-base mx-auto pl-4" style="color:rgba(50, 11, 78, 1)">
          Edit Chat
        </h1>
        <div class="justify-end">
          <p class="font-semibold text-lg text-blue-400">
            Baca Semua
          </p>
        </div>
      </div>
      <div class="px-12 py-4">
        <div class=" w-full">
          <input type="search" placeholder="Cari" class="border-blue-300 text-sm text-gray-400 border w-full py-2 rounded-md pl-12 pr-4 focus:outline-none focus:border-blue-500 transition duration-300">
          <div class="-translate-y-7 flex items-center pl-4">
            <img src="cari.svg" alt="">
          </div>
        </div>
      </div>
      <div class="pl-4">
        <div class="flex w-full items-center">
          <input id="default-checkbox" type="checkbox" value="" class="w-6 h-6 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600">
          <div class="px-4">
            <div class=" text-center border w-12 h-12 rounded-full">
              <p class="text-2xl translate-y-1">
                L
              </p>
            </div>
          </div>
          <div class="flex flex-col border-b w-full">
            <h1 class="text-base font-semibold" style="color: rgba(68, 68, 68, 1);">
              Alvin
            </h1>
            <div class="flex justify-end -translate-x-13 -translate-y-4 pr-2">
              <p class=" text-xs font-normal text-gray-300">
                7 Mar
              </p>
            </div>
            <h1 class="text-xs font-normal w-96" style="color: rgba(68, 68, 68, 1);">
              Aku padamuu
            </h1>
            <div class="flex justify-end -translate-x-13 -translate-y-4 pr-2">
              <div class="w-4 h-4 rounded-full bg-blue-400 text-center">
                <p class="text-white text-xs font-normal">
                  7
                </p>
              </div>
            </div>
          </div>
        </div>
        <div class="flex w-full items-center py-2">
          <input id="default-checkbox" type="checkbox" value="" class="w-6 h-6 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600">
          <div class="px-4">
            <div class=" text-center border w-12 h-12 rounded-full">
              <p class="text-2xl translate-y-1">
                L
              </p>
            </div>
          </div>
          <div class="flex flex-col border-b w-full">
            <h1 class="text-base font-semibold" style="color: rgba(68, 68, 68, 1);">
              Alvin
            </h1>
            <div class="flex justify-end -translate-x-13 -translate-y-4 pr-2">
              <p class=" text-xs font-normal text-gray-300">
                7 Mar
              </p>
            </div>
            <h1 class="text-xs font-normal w-96" style="color: rgba(68, 68, 68, 1);">
              Aku padamuu
            </h1>
            <div class="flex justify-end -translate-x-13 -translate-y-4 pr-2">
              <div class="w-4 h-4 rounded-full bg-blue-400 text-center">
                <p class="text-white text-xs font-normal">
                  7
                </p>
              </div>
            </div>
          </div>
        </div>
        <div class="translate-y-72">
          <div class="flex pr-4">
            <div class="w-12 h-10 rounded-lg" style="background-color: rgba(235, 235, 235, 1)">
              <div class="flex justify-center translate-y-1">
                <svg width="21" height="27" viewBox="0 0 21 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M0 10.5909L3.42857 8H14.5714L18 10.5909V27H0V10.5909Z" fill="#A6A6A6" />
                  <path d="M4.05882 9L2 11H16L13.9412 9H4.05882Z" fill="#E6E6E6" />
                  <path d="M9.47204 3.08858L8.73 7.78461L12.9321 5.56062L11.0257 4.19857L9.47204 3.08858Z" fill="#BDB4B4" />
                  <path d="M8.73 7.78461L9.47204 3.08858L12.9321 5.56062L8.73 7.78461ZM8.73 7.78461C10.5017 4.69526 14.1062 -1.83154 19.6062 2.66846" stroke="#BDB4B4" stroke-width="2" />
                </svg>
              </div>
            </div>
            <div class="px-4">
              <div class="border w-60 rounded-lg">
                hh
              </div>
            </div>
            <div class="">
              <div class="border w-56 rounded-lg">
                hh
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
