<template>
  <div>
    <div class="max-w-xl w-full mx-auto">
      <div class="bg-white shadow-lg my-0 mx-auto border-b">
        <div class="flex px-4 py-4">
          <div class="w-full">
            <input type="search" placeholder="Cari" class="px-4 py-2 border-4 rounded-full border-blue-200 w-full focus:outline-none focus:border-blue-500 transition-all placeholder:text-blue-200">
          </div>
          <img src="titik.svg" alt="" class="pl-4">
        </div>
      </div>
      <div class="bg-white shadow-lg border-b">
        <div class="px-8 py-4">
          <div class="flex">
            <div class="flex flex-col">
              <a href="/tambahteman">
                <img src="pren.svg" alt="" class="w-12 translate-x-2">
                <h1 class="text-xs font-medium" style="color: rgba(170, 170, 170, 1);">
                  Add Friend
                </h1>
              </a>
            </div>
            <div class="flex flex-col pl-8">
              <a href="/tambahgroup">
                <img src="grup.svg" alt="" class="w-12 translate-x-2">
                <h1 class="text-xs font-medium text-center" style="color: rgba(170, 170, 170, 1);">
                  New Group
                </h1>
              </a>
            </div>
          </div>
        </div>
      </div>
      <div class="bg-white shadow-lg border-b">
        <div class="py-2 border-b">
          <div class="flex justify-between px-4">
            <h1 class="text-sm font-normal" style="color: rgba(68, 68, 68, 1)">
              Group (2)
            </h1>
            <div class="translate-y-2">
              <svg width="12" height="7" viewBox="0 0 12 7" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M10.1611 6.68907L5.99463 2.56454L1.82819 6.68907C1.4094 7.10364 0.732886 7.10364 0.314095 6.68907C-0.104697 6.27449 -0.104697 5.60478 0.314095 5.19021L5.24295 0.310934C5.66175 -0.103645 6.33826 -0.103645 6.75705 0.310934L11.6859 5.19021C12.1047 5.60478 12.1047 6.27449 11.6859 6.68907C11.2671 7.09301 10.5799 7.10364 10.1611 6.68907Z" fill="#444444" />
              </svg>
            </div>
          </div>
          <div class="pt-4 pl-4">
            <div class="flex w-full items-center">
              <div class="px-4">
                <div class=" text-center border w-12 h-12 rounded-full">
                  <p class="text-2xl translate-y-1">
                    L
                  </p>
                </div>
              </div>
              <div class="flex flex-col border-b w-full">
                <h1 class="text-base font-semibold" style="color: rgba(68, 68, 68, 1);">
                  Alvin
                </h1>
                <div class="flex justify-end -translate-x-13 -translate-y-4 pr-2">
                  <p class=" text-xs font-normal text-gray-300">
                    7 Mar
                  </p>
                </div>
                <h1 class="text-xs font-normal w-96" style="color: rgba(68, 68, 68, 1);">
                  Aku padamuu
                </h1>
                <div class="flex justify-end -translate-x-13 -translate-y-4 pr-2">
                  <div class="w-4 h-4 rounded-full bg-blue-400 text-center">
                    <p class="text-white text-xs font-normal">
                      7
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div class="flex w-full py-4">
              <div class="px-4">
                <div class=" text-center border w-12 h-12 rounded-full">
                  <p class="text-2xl translate-y-1">
                    L
                  </p>
                </div>
              </div>
              <div class="flex flex-col border-b w-full">
                <h1 class="text-base font-semibold" style="color: rgba(68, 68, 68, 1);">
                  Alvin
                </h1>
                <div class="flex justify-end -translate-x-13 -translate-y-4 pr-2">
                  <p class=" text-xs font-normal text-gray-300">
                    7 Mar
                  </p>
                </div>
                <h1 class="text-xs font-normal w-96" style="color: rgba(68, 68, 68, 1);">
                  Aku padamuu
                </h1>
                <div class="flex justify-end -translate-x-13 -translate-y-4 pr-2">
                  <div class="w-4 h-4 rounded-full bg-blue-400 text-center">
                    <p class="text-white text-xs font-normal">
                      7
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="bg-white shadow-lg border-b">
        <div class="py-2 border-b">
          <div class="flex justify-between px-4">
            <h1 class="text-sm font-normal" style="color: rgba(68, 68, 68, 1)">
              Friend (2)
            </h1>
            <div class="translate-y-2">
              <svg width="12" height="7" viewBox="0 0 12 7" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M10.1611 6.68907L5.99463 2.56454L1.82819 6.68907C1.4094 7.10364 0.732886 7.10364 0.314095 6.68907C-0.104697 6.27449 -0.104697 5.60478 0.314095 5.19021L5.24295 0.310934C5.66175 -0.103645 6.33826 -0.103645 6.75705 0.310934L11.6859 5.19021C12.1047 5.60478 12.1047 6.27449 11.6859 6.68907C11.2671 7.09301 10.5799 7.10364 10.1611 6.68907Z" fill="#444444" />
              </svg>
            </div>
          </div>
          <div class="pt-4 pl-4">
            <div class="flex w-full">
              <div class="px-4">
                <div class=" text-center border w-12 h-12 rounded-full">
                  <p class="text-2xl translate-y-1">
                    L
                  </p>
                </div>
              </div>
              <div class="flex flex-col border-b w-full">
                <h1 class="text-base font-semibold" style="color: rgba(68, 68, 68, 1);">
                  Alvin
                </h1>
                <div class="flex justify-end -translate-x-13 -translate-y-4 pr-2">
                  <p class=" text-xs font-normal text-gray-300">
                    7 Mar
                  </p>
                </div>
                <h1 class="text-xs font-normal w-96" style="color: rgba(68, 68, 68, 1);">
                  Aku padamuu
                </h1>
                <div class="flex justify-end -translate-x-13 -translate-y-4 pr-2">
                  <div class="w-4 h-4 rounded-full bg-blue-400 text-center">
                    <p class="text-white text-xs font-normal">
                      7
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div class="flex w-full py-4">
              <div class="px-4">
                <div class=" text-center border w-12 h-12 rounded-full">
                  <p class="text-2xl translate-y-1">
                    L
                  </p>
                </div>
              </div>
              <div class="flex flex-col border-b w-full">
                <h1 class="text-base font-semibold" style="color: rgba(68, 68, 68, 1);">
                  Alvin
                </h1>
                <div class="flex justify-end -translate-x-13 -translate-y-4 pr-2">
                  <p class=" text-xs font-normal text-gray-300">
                    7 Mar
                  </p>
                </div>
                <h1 class="text-xs font-normal w-96" style="color: rgba(68, 68, 68, 1);">
                  Aku padamuu
                </h1>
                <div class="flex justify-end -translate-x-13 -translate-y-4 pr-2">
                  <div class="w-4 h-4 rounded-full bg-blue-400 text-center">
                    <p class="text-white text-xs font-normal">
                      7
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="my-0 mx-auto min-h-full max-w-xl">
        <div class="my-0 mx-auto max-w-xl translate-y-6 pt-4">
          <div class="w-full bg-white  shadow-md py-4">
            <div>
              <ul class="flex justify-between px-14 items-center">
                <li>
                  <router-link to="/">
                    <img src="/app/home2.svg" class="pl-2">
                    <div class="text-gray-400 text-center">
                      Home
                    </div>
                  </router-link>
                </li>
                <li class="text-white">
                  <a href="https://meet.google.com/pwg-zcyr-bcp">
                    <img src="/app/meet.svg" alt="">
                    <span class="text-gray-400 ">Meet</span>
                  </a>
                </li>
                <li>
                  <router-link to="/chat">
                    <img src="/app/pesan2.svg" alt="">
                    <span class="text-blue-500">Chat</span>
                  </router-link>
                </li>
                <li>
                  <router-link to="/proflogin">
                    <img src="/app/profil.svg" class="pl-2">
                    <span class="text-gray-400">Profile</span>
                  </router-link>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
