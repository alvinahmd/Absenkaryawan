<template>
  <div>
    <div class="max-w-screen-sm mx-auto h-screen shadow-xl">
      <div class="flex justify-center items-center pt-64">
        <a href="/login">
          <img src="/manggala0.png" class="mx-auto">
        </a>
      </div>
    </div>
  </div>
</template>
