<template>
  <div>
    <div class="max-w-screen-sm mx-auto  h-screen shadow-xl">
      <div class="relative flex flex-row py-5 px-4 bg-white shadow-lg">
        <router-link to="/proflogin">
          <img src="/back.svg">
        </router-link>
      </div>
      <div class="flex justify-center items-center pt-56">
        <img src="/newemail.png" class="mx-auto">
      </div>
      <h1 class="font-bold text-2xl text-gray-500 pl-60 py-2 mx-auto">
        verifikasi email
      </h1>
      <h1 class="font-semibold text-gray-400 pl-44 mx-auto">
        Kami harus Verifikasi email lama anda
      </h1>
      <h1 class="font-semibold text-gray-400 pl-32 mx-auto">
        fransciesco.steinlie@gmail jika mau mengganti akun
      </h1>
    </div>
  </div>
</template>
