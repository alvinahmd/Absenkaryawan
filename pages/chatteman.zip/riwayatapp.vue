<template>
  <div class="max-w-xl w-full mx-auto">
    <div class="flex py-5 px-4 bg-white shadow-xl">
      <div class="flex">
        <a href="/homeapp">
          <svg width="11" height="19" viewBox="0 0 11 19" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 2L3 9.1875L9 17" stroke="#0075FF" stroke-width="4" stroke-linecap="round" />
          </svg>
        </a>
        <h1 class="font-medium text-base mx-auto pl-4" style="color:rgba(50, 11, 78, 1)">
          Riwayat
        </h1>
      </div>
    </div>
    <div class="bg-white h-screen shadow-lg border-t-2">
      <div class="pt-4">
        <div class="px-4">
          <a href="/rekabbulan">
            <div class="w-full h-20 rounded-lg" style="background-color: rgba(251, 254, 255, 1); box-shadow: 0px 0px 4px 1px rgba(0, 0, 0, 0.25);">
              <h1 class="translate-x-48 translate-y-6 inline-block text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-teal-300 via-blue-500 to-purple-700">
                Desember 2022
              </h1>
            </div>
          </a>
        </div>
      </div>
      <div class="pt-4">
        <div class="px-4">
          <div class="w-full h-20 rounded-lg" style="background-color: rgba(251, 254, 255, 1); box-shadow: 0px 0px 4px 1px rgba(0, 0, 0, 0.25);">
            <h1 class="translate-x-48 translate-y-6 inline-block text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-teal-300 via-blue-500 to-purple-700">
              Januari 2023
            </h1>
          </div>
        </div>
      </div>
      <div class="pt-4">
        <div class="px-4">
          <div class="w-full h-20 rounded-lg" style="background-color: rgba(251, 254, 255, 1); box-shadow: 0px 0px 4px 1px rgba(0, 0, 0, 0.25);">
            <h1 class="translate-x-48 translate-y-6 inline-block text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-teal-300 via-blue-500 to-purple-700">
              Februari 2023
            </h1>
          </div>
        </div>
      </div>
      <div class="pt-4">
        <div class="px-4">
          <div class="w-full h-20 rounded-lg" style="background-color: rgba(251, 254, 255, 1); box-shadow: 0px 0px 4px 1px rgba(0, 0, 0, 0.25);">
            <h1 class="translate-x-48 translate-y-6 inline-block text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-teal-300 via-blue-500 to-purple-700">
              Maret 2022
            </h1>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
