<template>
  <div>
    <div class="max-w-xl w-full mx-auto bg-white shadow-lg h-screen">
      <div class="flex border-b-2 py-2">
        <a href="/temankosong" class="pl-4">
          <svg width="11" height="19" viewBox="0 0 11 19" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 2L3 9.1875L9 17" stroke="#0075FF" stroke-width="4" stroke-linecap="round" />
          </svg>
        </a>
        <h1 class="font-medium text-base mx-auto pl-4" style="color:rgba(50, 11, 78, 1)">
          Friends Requests
        </h1>
      </div>
      <div class="pt-2 pl-4">
        <div class="flex w-full">
          <div class="px-4">
            <div class=" text-center border w-12 h-12 rounded-full">
              <p class="text-2xl translate-y-1">
                L
              </p>
            </div>
          </div>
          <div class="flex flex-col border-b w-full">
            <div class="flex">
              <h1 class="text-base font-semibold" style="color: rgba(68, 68, 68, 1);">
                Alvinn
              </h1>
            </div>
            <h1 class="text-xs font-normal w-96" style="color: rgba(68, 68, 68, 1);">
              Permintaan Pertemanan dari Alvin
            </h1>
            <div class="flex justify-end -translate-x-8 -translate-y-8">
              <div class="pl-4">
                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M25 12.5C25 19.4036 19.4036 25 12.5 25C5.59644 25 0 19.4036 0 12.5C0 5.59644 5.59644 0 12.5 0C19.4036 0 25 5.59644 25 12.5Z" fill="#0075FF" />
                  <path d="M12.7798 17.0381L18.6827 9.28809V9.24934C18.7862 9.11364 18.8619 8.95889 18.9056 8.79392C18.9492 8.62896 18.96 8.45701 18.9372 8.28789C18.9144 8.11877 18.8585 7.95579 18.7727 7.80827C18.687 7.66075 18.573 7.53156 18.4373 7.42809C18.3016 7.32462 18.1468 7.24889 17.9819 7.20522C17.8169 7.16156 17.6449 7.15082 17.4758 7.1736C17.3067 7.19639 17.1437 7.25227 16.9962 7.33804C16.8487 7.42382 16.7195 7.53781 16.616 7.67351L11.7335 14.1318L9.62811 11.4452C9.52379 11.3112 9.39409 11.199 9.24644 11.1151C9.09878 11.0313 8.93604 10.9773 8.76752 10.9563C8.42718 10.9139 8.08395 11.0084 7.81331 11.2191C7.67931 11.3235 7.56717 11.4531 7.48328 11.6008C7.3994 11.7485 7.34543 11.9112 7.32444 12.0797C7.30345 12.2482 7.31585 12.4192 7.36095 12.583C7.40605 12.7467 7.48295 12.8999 7.58727 13.0339L10.7389 17.051C10.8606 17.2049 11.0157 17.3292 11.1925 17.4142C11.3693 17.4992 11.5632 17.5429 11.7594 17.5418C11.9566 17.5414 12.1511 17.4957 12.328 17.4084C12.5049 17.3211 12.6594 17.1944 12.7798 17.0381Z" fill="white" />
                </svg>
              </div>
              <div class="pl-2">
                <div class="w-6 h-6 bg-red-500 rounded-full">
                  <div class="flex justify-center translate-y-1.5">
                    <svg width="12" height="13" viewBox="0 0 12 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <rect
                        x="0.515625"
                        y="10.4053"
                        width="13.0791"
                        height="3"
                        rx="1.5"
                        transform="rotate(-52.708 0.515625 10.4053)"
                        fill="white"
                      />
                      <rect width="13.0791" height="3" rx="1.5" transform="matrix(-0.704385 -0.709819 -0.709819 0.704385 11.3423 9.69678)" fill="white" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="pt-2 pl-4">
        <div class="flex w-full">
          <div class="px-4">
            <div class=" text-center border w-12 h-12 rounded-full">
              <p class="text-2xl translate-y-1">
                L
              </p>
            </div>
          </div>
          <div class="flex flex-col border-b w-full">
            <div class="flex">
              <h1 class="text-base font-semibold" style="color: rgba(68, 68, 68, 1);">
                Alvinn
              </h1>
            </div>
            <h1 class="text-xs font-normal w-96" style="color: rgba(68, 68, 68, 1);">
              Permintaan Pertemanan dari Alvin
            </h1>
            <div class="flex justify-end -translate-x-8 -translate-y-8">
              <div class="pl-4">
                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M25 12.5C25 19.4036 19.4036 25 12.5 25C5.59644 25 0 19.4036 0 12.5C0 5.59644 5.59644 0 12.5 0C19.4036 0 25 5.59644 25 12.5Z" fill="#0075FF" />
                  <path d="M12.7798 17.0381L18.6827 9.28809V9.24934C18.7862 9.11364 18.8619 8.95889 18.9056 8.79392C18.9492 8.62896 18.96 8.45701 18.9372 8.28789C18.9144 8.11877 18.8585 7.95579 18.7727 7.80827C18.687 7.66075 18.573 7.53156 18.4373 7.42809C18.3016 7.32462 18.1468 7.24889 17.9819 7.20522C17.8169 7.16156 17.6449 7.15082 17.4758 7.1736C17.3067 7.19639 17.1437 7.25227 16.9962 7.33804C16.8487 7.42382 16.7195 7.53781 16.616 7.67351L11.7335 14.1318L9.62811 11.4452C9.52379 11.3112 9.39409 11.199 9.24644 11.1151C9.09878 11.0313 8.93604 10.9773 8.76752 10.9563C8.42718 10.9139 8.08395 11.0084 7.81331 11.2191C7.67931 11.3235 7.56717 11.4531 7.48328 11.6008C7.3994 11.7485 7.34543 11.9112 7.32444 12.0797C7.30345 12.2482 7.31585 12.4192 7.36095 12.583C7.40605 12.7467 7.48295 12.8999 7.58727 13.0339L10.7389 17.051C10.8606 17.2049 11.0157 17.3292 11.1925 17.4142C11.3693 17.4992 11.5632 17.5429 11.7594 17.5418C11.9566 17.5414 12.1511 17.4957 12.328 17.4084C12.5049 17.3211 12.6594 17.1944 12.7798 17.0381Z" fill="white" />
                </svg>
              </div>
              <div class="pl-2">
                <div class="w-6 h-6 bg-red-500 rounded-full">
                  <div class="flex justify-center translate-y-1.5">
                    <svg width="12" height="13" viewBox="0 0 12 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <rect
                        x="0.515625"
                        y="10.4053"
                        width="13.0791"
                        height="3"
                        rx="1.5"
                        transform="rotate(-52.708 0.515625 10.4053)"
                        fill="white"
                      />
                      <rect width="13.0791" height="3" rx="1.5" transform="matrix(-0.704385 -0.709819 -0.709819 0.704385 11.3423 9.69678)" fill="white" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="pt-2 pl-4">
        <div class="flex w-full">
          <div class="px-4">
            <div class=" text-center border w-12 h-12 rounded-full">
              <p class="text-2xl translate-y-1">
                L
              </p>
            </div>
          </div>
          <div class="flex flex-col border-b w-full">
            <div class="flex">
              <h1 class="text-base font-semibold" style="color: rgba(68, 68, 68, 1);">
                Alvinn
              </h1>
            </div>
            <h1 class="text-xs font-normal w-96" style="color: rgba(68, 68, 68, 1);">
              Permintaan Pertemanan dari Alvin
            </h1>
            <div class="flex justify-end -translate-x-8 -translate-y-8">
              <div class="pl-4">
                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M25 12.5C25 19.4036 19.4036 25 12.5 25C5.59644 25 0 19.4036 0 12.5C0 5.59644 5.59644 0 12.5 0C19.4036 0 25 5.59644 25 12.5Z" fill="#0075FF" />
                  <path d="M12.7798 17.0381L18.6827 9.28809V9.24934C18.7862 9.11364 18.8619 8.95889 18.9056 8.79392C18.9492 8.62896 18.96 8.45701 18.9372 8.28789C18.9144 8.11877 18.8585 7.95579 18.7727 7.80827C18.687 7.66075 18.573 7.53156 18.4373 7.42809C18.3016 7.32462 18.1468 7.24889 17.9819 7.20522C17.8169 7.16156 17.6449 7.15082 17.4758 7.1736C17.3067 7.19639 17.1437 7.25227 16.9962 7.33804C16.8487 7.42382 16.7195 7.53781 16.616 7.67351L11.7335 14.1318L9.62811 11.4452C9.52379 11.3112 9.39409 11.199 9.24644 11.1151C9.09878 11.0313 8.93604 10.9773 8.76752 10.9563C8.42718 10.9139 8.08395 11.0084 7.81331 11.2191C7.67931 11.3235 7.56717 11.4531 7.48328 11.6008C7.3994 11.7485 7.34543 11.9112 7.32444 12.0797C7.30345 12.2482 7.31585 12.4192 7.36095 12.583C7.40605 12.7467 7.48295 12.8999 7.58727 13.0339L10.7389 17.051C10.8606 17.2049 11.0157 17.3292 11.1925 17.4142C11.3693 17.4992 11.5632 17.5429 11.7594 17.5418C11.9566 17.5414 12.1511 17.4957 12.328 17.4084C12.5049 17.3211 12.6594 17.1944 12.7798 17.0381Z" fill="white" />
                </svg>
              </div>
              <div class="pl-2">
                <div class="w-6 h-6 bg-red-500 rounded-full">
                  <div class="flex justify-center translate-y-1.5">
                    <svg width="12" height="13" viewBox="0 0 12 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <rect
                        x="0.515625"
                        y="10.4053"
                        width="13.0791"
                        height="3"
                        rx="1.5"
                        transform="rotate(-52.708 0.515625 10.4053)"
                        fill="white"
                      />
                      <rect width="13.0791" height="3" rx="1.5" transform="matrix(-0.704385 -0.709819 -0.709819 0.704385 11.3423 9.69678)" fill="white" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
