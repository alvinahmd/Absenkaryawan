<template>
  <div>
    <div class="mx-auto w-full max-w-xl bg-white shadow-lg h-full">
      <div class="py-4">
        <div class="flex border-b-2">
          <a href="/homeapp" class="pl-4">
            <svg width="11" height="19" viewBox="0 0 11 19" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M9 2L3 9.1875L9 17" stroke="#0075FF" stroke-width="4" stroke-linecap="round" />
            </svg>
          </a>
          <h1 class="font-medium text-base mx-auto pl-4" style="color:rgba(50, 11, 78, 1)">
            Friends Requests
          </h1>
        </div>
        <div class="px-4">
          <div class="px-12 py-12">
            <a href="/temanreq">
              <img src="orang.svg" class="px-12 w-full">
              <div class=" text-center">
                <p class="text-lg font-medium" style="color: rgba(68, 68, 68, 1)">
                  Tidak Ada Permintaan Masuk
                </p>
                <p class="text-sm font-medium" style="color: rgba(147, 147, 147, 1);">
                  Ketika ada permintaan masuk,anda dapat mengaksesnya di sini!
                </p>
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
