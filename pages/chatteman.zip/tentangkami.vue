<template>
  <div>
    <div class="my-0 mx-auto min-h-full max-w-screen-sm">
      <div class="relative flex flex-row py-5 px-4 bg-white shadow-lg">
        <router-link to="/proflogin">
          <img src="/back.svg">
        </router-link>
        <h1 class="font-bold text-2xl mx-auto" style="color:rgba(68, 68, 68, 1)">
          Tentang Kami
        </h1>
      </div>
      <div class="py-4 px-20">
        <img src="/manggala2.svg" class="px-28 items-center">
        <div class=" container p-5 pb-60 bg-white">
          <div class="pl-5 ">
            <p class="text-xl poppins" style="color:rgba(92, 92, 92, 1);">
              Manggala Technology are business solutions tailored by technology experts to streamline the operations of any business residing in any industry. Our products promote your business to wield efficiency, productivity and control to become leaders in the market.
            </p>
          </div>
        </div>
      </div>
      <div class="my-0 mx-auto min-h-full max-w-screen-sm">
        <div class="container mb-4" />
        <div class="w-full bg-white py-4">
          <div>
            <div class="flex justify-between px-2 items-center">
              <img src="/logoo.png" class="mx-auto">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
